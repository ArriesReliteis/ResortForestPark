﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;
using ResortForestPark.Models;
using ResortForestPark.Windows;

namespace ResortForestPark.Pages;

public partial class LoginHistoryPage : Page
{
    private List<LoginHistory> history = new List<LoginHistory>();

    public LoginHistoryPage()
    {
        InitializeComponent();
        LoadHistory();
    }

    private void LoadHistory()
    {
        try
        {
            using var db = new ResortForestParkContext();
            history = db.LoginHistories
                .Include(h => h.Employee)
                .Include(h => h.LoginType)
                .OrderByDescending(h => h.AttemptTime)
                .ToList();
            ApplyFilter();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Не удалось загрузить историю входа\n" + ex.Message,
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    // История загружается один раз, фильтр по логину применяется к уже загруженному списку
    private void ApplyFilter()
    {
        string login = LoginFilterTextBox.Text.Trim();
        HistoryListView.ItemsSource = history
            .Where(h => h.Employee.Login.Contains(login, StringComparison.OrdinalIgnoreCase))
            .ToList();
    }

    private void LoginFilterTextBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        ApplyFilter();
    }

    private void AllOrdersButton_Click(object sender, RoutedEventArgs e)
    {
        new OrdersWindow().ShowDialog();
    }
}
