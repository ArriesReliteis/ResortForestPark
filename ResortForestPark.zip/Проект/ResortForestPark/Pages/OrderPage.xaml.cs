﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using ResortForestPark.Models;
using ResortForestPark.Windows;

namespace ResortForestPark.Pages;

public partial class OrderPage : Page
{
    // Услуги текущего заказа, ObservableCollection сама обновляет список на экране при добавлении и удалении
    private ObservableCollection<Service> orderServices = new ObservableCollection<Service>();
    private List<Client> clients = new List<Client>();
    private List<Service> services = new List<Service>();

    public OrderPage()
    {
        InitializeComponent();
        OrderServicesListView.ItemsSource = orderServices;
        LoadData();
    }

    private void LoadData()
    {
        try
        {
            using var db = new ResortForestParkContext();
            clients = db.Clients.OrderBy(c => c.LastName).ToList();
            services = db.Services.OrderBy(s => s.Name).ToList();
            FilterClients();
            FilterServices();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Не удалось загрузить данные\n" + ex.Message,
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void ClientSearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        FilterClients();
    }

    private void FilterClients()
    {
        string text = ClientSearchTextBox.Text.Trim();
        ClientsListView.ItemsSource = clients.Where(c => c.ClientCode.ToString().Contains(text)
            || c.FullName.Contains(text, StringComparison.OrdinalIgnoreCase)).ToList();
    }

    private void ClientsButton_Click(object sender, RoutedEventArgs e)
    {
        var window = new ClientsWindow();
        window.ShowDialog();
        if (window.AddedClientCode == null)
            return;

        try
        {
            using var db = new ResortForestParkContext();
            clients = db.Clients.OrderBy(c => c.LastName).ToList();
            ClientSearchTextBox.Text = window.AddedClientCode.ToString();
            FilterClients();
            ClientsListView.SelectedItem = clients.FirstOrDefault(c => c.ClientCode == window.AddedClientCode);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Не удалось обновить список клиентов\n" + ex.Message,
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void ServiceSearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        FilterServices();
    }

    private void FilterServices()
    {
        string text = ServiceSearchTextBox.Text.Trim();
        ServicesListView.ItemsSource = services.Where(s => s.Code.Contains(text, StringComparison.OrdinalIgnoreCase)
            || s.Name.Contains(text, StringComparison.OrdinalIgnoreCase)
            || s.PricePerHour.ToString("0.##").Contains(text)).ToList();
    }

    private void AddServiceButton_Click(object sender, RoutedEventArgs e)
    {
        if (ServicesListView.SelectedItem is not Service service)
        {
            ShowWarning("Выберите услугу в списке");
            return;
        }

        if (orderServices.Any(s => s.Id == service.Id))
        {
            ShowWarning("Эта услуга уже добавлена в заказ");
            return;
        }

        orderServices.Add(service);
    }

    private void RemoveServiceButton_Click(object sender, RoutedEventArgs e)
    {
        // Кнопка ✕ находится в строке списка, её DataContext — услуга этой строки
        var service = (Service)((Button)sender).DataContext;
        orderServices.Remove(service);
    }

    private void DigitsOnly_PreviewTextInput(object sender, TextCompositionEventArgs e)
    {
        e.Handled = !e.Text.All(char.IsDigit);
    }

    private void CreateOrderButton_Click(object sender, RoutedEventArgs e)
    {
        if (!int.TryParse(RentalMinutesTextBox.Text, out int rentalMinutes) || rentalMinutes < 1 || rentalMinutes > 720)
        {
            ShowWarning("Неверно указано время проката");
            return;
        }
        if (ClientsListView.SelectedItem is not Client client)
        {
            ShowWarning("Выберите клиента");
            return;
        }
        if (orderServices.Count == 0)
        {
            ShowWarning("Добавьте в заказ хотя бы одну услугу");
            return;
        }

        try
        {
            using var db = new ResortForestParkContext();
            int newStatusId = db.OrderStatuses.Where(s => s.Name == "Новая")
                .Select(s => s.Id).First();

            DateTime now = DateTime.Now;
            var order = new Order
            {
                // Код заказа: код клиента/дата, как в импортированных данных
                OrderCode = $"{client.ClientCode}/{now:dd.MM.yyyy}",
                CreatedDate = DateOnly.FromDateTime(now),
                CreatedTime = new TimeOnly(now.Hour, now.Minute, now.Second),
                ClientCode = client.ClientCode,
                OrderStatusId = newStatusId,
                RentalMinutes = rentalMinutes
            };
            foreach (Service service in orderServices)
                order.OrderServices.Add(new OrderService { ServiceId = service.Id });
            db.Orders.Add(order);
            db.SaveChanges();

            MessageBox.Show($"Заказ № {order.Id} ({order.OrderCode}) оформлен", "Оформление заказа",
                MessageBoxButton.OK, MessageBoxImage.Information);
            ResetForm();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Не удалось сохранить заказ\n" + ex.Message,
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void ResetForm()
    {
        RentalMinutesTextBox.Clear();
        ClientSearchTextBox.Clear();
        ClientsListView.SelectedItem = null;
        ServiceSearchTextBox.Clear();
        orderServices.Clear();
    }

    private static void ShowWarning(string text)
    {
        MessageBox.Show(text, "Оформление заказа", MessageBoxButton.OK, MessageBoxImage.Warning);
    }
}
