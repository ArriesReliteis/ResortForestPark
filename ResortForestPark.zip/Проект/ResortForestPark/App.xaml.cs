using System.Windows;

namespace ResortForestPark;

public partial class App : Application
{
    public const string SellerRole = "Продавец";
    public const string ShiftSeniorRole = "Старший смены";
    public const string AdminRole = "Администратор";

    public const string ConnectionString =
        "Server=192.168.1.7;Database=ResortForestPark;User Id=sqluser;Password=SqlDatabaseUser!1212;TrustServerCertificate=True";
}
