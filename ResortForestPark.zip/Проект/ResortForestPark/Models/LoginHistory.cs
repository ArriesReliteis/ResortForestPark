﻿using System;
using System.Collections.Generic;

namespace ResortForestPark.Models;

public partial class LoginHistory
{
    public int Id { get; set; }

    public int EmployeeCode { get; set; }

    public DateTime AttemptTime { get; set; }

    public int LoginTypeId { get; set; }

    public virtual Employee Employee { get; set; } = null!;

    public virtual LoginType LoginType { get; set; } = null!;
}
