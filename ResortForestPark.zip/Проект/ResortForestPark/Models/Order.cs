﻿using System;
using System.Collections.Generic;

namespace ResortForestPark.Models;

public partial class Order
{
    public int Id { get; set; }

    public string OrderCode { get; set; } = null!;

    public DateOnly CreatedDate { get; set; }

    public TimeOnly CreatedTime { get; set; }

    public int ClientCode { get; set; }

    public int OrderStatusId { get; set; }

    public DateOnly? ClosedDate { get; set; }

    public int RentalMinutes { get; set; }

    public virtual Client Client { get; set; } = null!;

    public virtual OrderStatus OrderStatus { get; set; } = null!;

    public virtual ICollection<OrderService> OrderServices { get; set; } = new List<OrderService>();

    // Названия услуг заказа через запятую (для окна «Все заказы»)
    public string ServicesText => string.Join(", ", OrderServices.Select(os => os.Service.Name));
}
