﻿using System;
using System.Collections.Generic;

namespace ResortForestPark.Models;

public partial class Employee
{
    public int Id { get; set; }

    public int EmployeeCode { get; set; }

    public int RoleId { get; set; }

    public string LastName { get; set; } = null!;

    public string FirstName { get; set; } = null!;

    public string? Patronymic { get; set; }

    public string Login { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string? Photo { get; set; }

    public virtual Role Role { get; set; } = null!;

    public virtual ICollection<LoginHistory> LoginHistories { get; set; } = new List<LoginHistory>();

    public string FullName => $"{LastName} {FirstName} {Patronymic}".Trim();
}
