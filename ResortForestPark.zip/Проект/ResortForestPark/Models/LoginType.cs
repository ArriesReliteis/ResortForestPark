using System;
using System.Collections.Generic;

namespace ResortForestPark.Models;

public partial class LoginType
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public virtual ICollection<LoginHistory> LoginHistories { get; set; } = new List<LoginHistory>();
}
