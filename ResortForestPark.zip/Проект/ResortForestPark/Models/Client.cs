﻿using System;
using System.Collections.Generic;

namespace ResortForestPark.Models;

public partial class Client
{
    public int Id { get; set; }

    public int ClientCode { get; set; }

    public string LastName { get; set; } = null!;

    public string FirstName { get; set; } = null!;

    public string? Patronymic { get; set; }

    public string PassportSeries { get; set; } = null!;

    public string PassportNumber { get; set; } = null!;

    public DateOnly BirthDate { get; set; }

    public string Address { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string? Password { get; set; }

    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();

    public string FullName => $"{LastName} {FirstName} {Patronymic}".Trim();

    public string Passport => $"{PassportSeries} {PassportNumber}";
}
