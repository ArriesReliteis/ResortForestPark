using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using ResortForestPark.Models;
using ResortForestPark.Pages;

namespace ResortForestPark.Windows;

public partial class MainWindow : Window
{
    private DispatcherTimer sessionTimer = new DispatcherTimer();
    private DateTime sessionStart = DateTime.Now;

    public MainWindow(Employee employee)
    {
        InitializeComponent();

        EmployeeNameTextBlock.Text = $"{employee.LastName} {employee.FirstName}";
        RoleTextBlock.Text = employee.Role.Name;
        ShowEmployeePhoto(employee.Photo);

        // Администратор видит историю входа, продавец и старший смены — оформление заказа
        if (employee.Role.Name == App.AdminRole)
            MainFrame.Navigate(new LoginHistoryPage());
        else
            MainFrame.Navigate(new OrderPage());

        sessionTimer.Interval = TimeSpan.FromSeconds(1);
        sessionTimer.Tick += SessionTimer_Tick;
        sessionTimer.Start();
    }

    // В базе хранится имя файла фото, сами файлы лежат в папке Images\Employees рядом с программой
    // Если фото нет, рамка под него скрывается
    private void ShowEmployeePhoto(string? photo)
    {
        string path = Path.Combine(AppContext.BaseDirectory, "Images", "Employees", Path.GetFileName(photo ?? ""));
        if (photo != null && File.Exists(path))
            EmployeePhotoImage.Source = new BitmapImage(new Uri(path));
        else
            EmployeePhotoBorder.Visibility = Visibility.Collapsed;
    }

    private void SessionTimer_Tick(object? sender, EventArgs e)
    {
        TimeSpan elapsed = DateTime.Now - sessionStart;
        SessionTimeTextBlock.Text = "Время сеанса: " + elapsed.ToString(@"hh\:mm\:ss");
    }

    private void LogoutButton_Click(object sender, RoutedEventArgs e)
    {
        sessionTimer.Stop();
        new LoginWindow().Show();
        Close();
    }
}
