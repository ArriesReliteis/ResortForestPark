using System.Windows;
using Microsoft.EntityFrameworkCore;
using ResortForestPark.Models;

namespace ResortForestPark.Windows;

public partial class OrdersWindow : Window
{
    public OrdersWindow()
    {
        InitializeComponent();
        LoadOrders();
    }

    private void LoadOrders()
    {
        try
        {
            using var db = new ResortForestParkContext();
            // Include подгружает связанные данные: клиента, статус и услуги заказа
            OrdersListView.ItemsSource = db.Orders
                .Include(o => o.Client)
                .Include(o => o.OrderStatus)
                .Include(o => o.OrderServices).ThenInclude(os => os.Service)
                .OrderByDescending(o => o.Id)
                .ToList();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Не удалось загрузить заказы\n" + ex.Message,
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void CloseButton_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}
