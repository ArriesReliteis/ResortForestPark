using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;
using Microsoft.EntityFrameworkCore;
using ResortForestPark.Models;

namespace ResortForestPark.Windows;

public partial class ClientWindow : Window
{
    public int SavedClientCode { get; private set; }

    public ClientWindow()
    {
        InitializeComponent();
        LoadNextClientCode();
    }

    private void LoadNextClientCode()
    {
        try
        {
            using var db = new ResortForestParkContext();
            // Новый код = последний код + 1
            // (int?) нужен, чтобы при пустой таблице получить null, а не ошибку
            int? lastCode = db.Clients.Max(c => (int?)c.ClientCode);
            CodeTextBox.Text = ((lastCode ?? 45462525) + 1).ToString();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Не удалось подключиться к базе данных\n" + ex.Message,
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    // Не даёт вводить в поле ничего, кроме цифр
    private void DigitsOnly_PreviewTextInput(object sender, TextCompositionEventArgs e)
    {
        e.Handled = !e.Text.All(char.IsDigit);
    }

    private void SaveButton_Click(object sender, RoutedEventArgs e)
    {
        string code = CodeTextBox.Text.Trim();
        string lastName = LastNameTextBox.Text.Trim();
        string firstName = FirstNameTextBox.Text.Trim();
        string patronymic = PatronymicTextBox.Text.Trim();
        DateTime? birthDate = BirthDatePicker.SelectedDate;
        string series = PassportSeriesTextBox.Text.Trim();
        string number = PassportNumberTextBox.Text.Trim();
        string address = AddressTextBox.Text.Trim();
        string email = EmailTextBox.Text.Trim();

        var errors = new List<string>();
        if (code.Length != 8 || !code.All(char.IsDigit))
            errors.Add("Неверно указан код клиента");
        if (lastName == "" || lastName.Any(char.IsDigit))
            errors.Add("Неверно указана фамилия");
        if (firstName == "" || firstName.Any(char.IsDigit))
            errors.Add("Неверно указано имя");
        if (patronymic.Any(char.IsDigit))
            errors.Add("Неверно указано отчество");
        if (birthDate == null || birthDate > DateTime.Today)
            errors.Add("Неверно указана дата рождения");
        if (series.Length != 4 || !series.All(char.IsDigit))
            errors.Add("Неверно указана серия паспорта");
        if (number.Length != 6 || !number.All(char.IsDigit))
            errors.Add("Неверно указан номер паспорта");
        if (address == "")
            errors.Add("Не указан адрес");
        if (!Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            errors.Add("Неверно указан E-mail");

        if (errors.Count > 0)
        {
            MessageBox.Show("Проверьте данные:\n\n" + string.Join("\n", errors),
                "Новый клиент", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        int clientCode = int.Parse(code);
        try
        {
            using var db = new ResortForestParkContext();
            if (db.Clients.Any(c => c.ClientCode == clientCode))
            {
                MessageBox.Show("Клиент с таким кодом уже существует", "Новый клиент",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            db.Clients.Add(new Client
            {
                ClientCode = clientCode,
                LastName = lastName,
                FirstName = firstName,
                Patronymic = patronymic == "" ? null : patronymic,
                BirthDate = DateOnly.FromDateTime(birthDate!.Value),
                PassportSeries = series,
                PassportNumber = number,
                Address = address,
                Email = email
            });
            db.SaveChanges();

            SavedClientCode = clientCode;
            MessageBox.Show("Клиент добавлен", "Новый клиент", MessageBoxButton.OK, MessageBoxImage.Information);
            DialogResult = true;
        }
        // На серию и номер паспорта в базе стоит ограничение уникальности,
        // поэтому при повторе паспорта база не даст сохранить клиента
        catch (DbUpdateException)
        {
            MessageBox.Show("Клиент с такими паспортными данными уже есть в базе", "Новый клиент",
                MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Не удалось сохранить клиента\n" + ex.Message,
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}
