using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.EntityFrameworkCore;
using ResortForestPark.Models;

namespace ResortForestPark.Windows;

public partial class LoginWindow : Window
{
    private Random random = new Random();
    private DispatcherTimer blockTimer = new DispatcherTimer();
    private string captchaText = "";
    private DateTime blockedUntil;

    public LoginWindow()
    {
        InitializeComponent();
        blockTimer.Interval = TimeSpan.FromSeconds(1);
        blockTimer.Tick += BlockTimer_Tick;
        GenerateCaptcha();
    }

    private void LoginButton_Click(object sender, RoutedEventArgs e)
    {
        string login = LoginTextBox.Text.Trim();
        string password = PasswordBox.Password;
        string captcha = CaptchaTextBox.Text.Trim();
        if (login == "" || password == "" || captcha == "")
        {
            ShowWarning("Введите логин, пароль и капчу");
            return;
        }

        try
        {
            using var db = new ResortForestParkContext();
            Employee? employee = db.Employees.Include(x => x.Role)
                .FirstOrDefault(x => x.Login == login);
            if (employee == null)
            {
                GenerateCaptcha();
                ShowWarning("Неверный логин");
                return;
            }

            // Блокировка берётся из истории входа: если последняя попытка сотрудника
            // неуспешная и с неё прошло меньше 10 секунд, вход пока запрещён
            // Последняя попытка — запись с наибольшим Id
            LoginHistory? lastAttempt = db.LoginHistories.Include(h => h.LoginType)
                .Where(h => h.EmployeeCode == employee.EmployeeCode)
                .OrderByDescending(h => h.Id)
                .FirstOrDefault();
            if (lastAttempt != null && lastAttempt.LoginType.Name == "Неуспешно"
                && lastAttempt.AttemptTime.AddSeconds(10) > DateTime.Now)
            {
                StartBlock(lastAttempt.AttemptTime.AddSeconds(10));
                return;
            }

            bool captchaCorrect = captcha.ToUpper() == captchaText;
            bool success = captchaCorrect && employee.Password == password;

            string loginTypeName = success ? "Успешно" : "Неуспешно";
            int loginTypeId = db.LoginTypes.Where(t => t.Name == loginTypeName)
                .Select(t => t.Id).First();
            DateTime now = DateTime.Now;
            db.LoginHistories.Add(new LoginHistory
            {
                EmployeeCode = employee.EmployeeCode,
                // Время без миллисекунд
                AttemptTime = new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, now.Second),
                LoginTypeId = loginTypeId
            });
            db.SaveChanges();

            if (success)
            {
                new MainWindow(employee).Show();
                Close();
                return;
            }

            GenerateCaptcha();
            StartBlock(now.AddSeconds(10));
            string reason = captchaCorrect ? "Неверный пароль" : "Неверная капча";
            ShowWarning(reason + "\nВход заблокирован на 10 секунд");
        }
        catch (Exception ex)
        {
            MessageBox.Show("Не удалось проверить вход\n" + ex.Message,
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    // Капча 3 случайных символа, каждый немного повёрнут, сверху перечёркивающие линии
    // Похожие символы (0 и O, 1 и I) не используются
    private void GenerateCaptcha()
    {
        string symbols = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        CaptchaCanvas.Children.Clear();
        CaptchaTextBox.Clear();
        captchaText = "";

        for (int i = 0; i < 3; i++)
        {
            char symbol = symbols[random.Next(symbols.Length)];
            captchaText += symbol;

            TextBlock letter = new TextBlock();
            letter.Text = symbol.ToString();
            letter.FontSize = 30;
            letter.FontWeight = FontWeights.Bold;
            letter.RenderTransform = new RotateTransform(random.Next(-20, 21));
            Canvas.SetLeft(letter, 40 + i * 45);
            Canvas.SetTop(letter, random.Next(0, 20));
            CaptchaCanvas.Children.Add(letter);
        }

        for (int i = 0; i < 3; i++)
        {
            Line line = new Line();
            line.X1 = 0;
            line.Y1 = random.Next(10, 50);
            line.X2 = 200;
            line.Y2 = random.Next(10, 50);
            line.Stroke = Brushes.Gray;
            line.StrokeThickness = 2;
            CaptchaCanvas.Children.Add(line);
        }
    }

    // Блокирует поля до указанного времени и запускает таймер обратного отсчёта
    private void StartBlock(DateTime until)
    {
        blockedUntil = until;
        SetInputEnabled(false);
        UpdateBlockText();
        blockTimer.Start();
    }

    private void BlockTimer_Tick(object? sender, EventArgs e)
    {
        if (DateTime.Now >= blockedUntil)
        {
            blockTimer.Stop();
            BlockTextBlock.Text = "";
            SetInputEnabled(true);
            return;
        }

        UpdateBlockText();
    }

    private void UpdateBlockText()
    {
        TimeSpan left = blockedUntil - DateTime.Now;
        BlockTextBlock.Text = "Вход заблокирован. Повторите попытку через " + left.ToString(@"mm\:ss");
    }

    private void SetInputEnabled(bool enabled)
    {
        LoginTextBox.IsEnabled = enabled;
        PasswordBox.IsEnabled = enabled;
        CaptchaTextBox.IsEnabled = enabled;
        LoginButton.IsEnabled = enabled;
    }

    private static void ShowWarning(string text)
    {
        MessageBox.Show(text, "Вход в систему", MessageBoxButton.OK, MessageBoxImage.Warning);
    }
}
