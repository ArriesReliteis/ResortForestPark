using System.Windows;
using ResortForestPark.Models;

namespace ResortForestPark.Windows;

public partial class ClientsWindow : Window
{
    // Код последнего добавленного клиента, чтобы выделить его в списке и в оформлении заказа
    public int? AddedClientCode { get; private set; }

    public ClientsWindow()
    {
        InitializeComponent();
        LoadClients();
    }

    private void LoadClients()
    {
        try
        {
            using var db = new ResortForestParkContext();
            List<Client> clients = db.Clients.OrderBy(c => c.LastName).ToList();
            ClientsListView.ItemsSource = clients;
            CountTextBlock.Text = $"Всего клиентов: {clients.Count}";

            Client? added = clients.FirstOrDefault(c => c.ClientCode == AddedClientCode);
            if (added != null)
            {
                ClientsListView.SelectedItem = added;
                ClientsListView.ScrollIntoView(added);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Не удалось загрузить клиентов\n" + ex.Message,
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void AddClientButton_Click(object sender, RoutedEventArgs e)
    {
        var window = new ClientWindow();
        if (window.ShowDialog() == true)
        {
            AddedClientCode = window.SavedClientCode;
            LoadClients();
        }
    }

    private void CloseButton_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}
