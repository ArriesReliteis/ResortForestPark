﻿create table Roles (
  Id int identity primary key,
  Name nvarchar(50) not null unique
);

create table Employees (
  Id int identity primary key,
  EmployeeCode int not null unique,
  RoleId int not null foreign key references Roles (Id),
  LastName nvarchar(50) not null,
  FirstName nvarchar(50) not null,
  Patronymic nvarchar(50),
  Login nvarchar(100) not null unique,
  Password nvarchar(100) not null,
  Photo nvarchar(100)
);

create table LoginTypes (
  Id int identity primary key,
  Name nvarchar(30) not null unique
);

create table LoginHistories (
  Id int identity primary key,
  EmployeeCode int not null foreign key references Employees (EmployeeCode),
  AttemptTime datetime2(0) not null,
  LoginTypeId int not null foreign key references LoginTypes (Id)
);

create table Clients (
  Id int identity primary key,
  ClientCode int not null unique,
  LastName nvarchar(50) not null,
  FirstName nvarchar(50) not null,
  Patronymic nvarchar(50),
  PassportSeries char(4) not null check (PassportSeries not like '%[^0-9]%' and len(PassportSeries) = 4),
  PassportNumber char(6) not null check (PassportNumber not like '%[^0-9]%' and len(PassportNumber) = 6),
  BirthDate date not null,
  Address nvarchar(200) not null,
  Email nvarchar(100) not null,
  Password nvarchar(100),
  unique (PassportSeries, PassportNumber)
);

create table Services (
  Id int identity primary key,
  Name nvarchar(100) not null,
  Code nvarchar(30) not null unique,
  PricePerHour decimal(10,2) not null check (PricePerHour >= 0)
);

create table OrderStatuses (
  Id int identity primary key,
  Name nvarchar(30) not null unique
);

create table Orders (
  Id int identity primary key,
  OrderCode nvarchar(30) not null,
  CreatedDate date not null,
  CreatedTime time(0) not null,
  ClientCode int not null foreign key references Clients (ClientCode),
  OrderStatusId int not null foreign key references OrderStatuses (Id),
  ClosedDate date,
  RentalMinutes int not null check (RentalMinutes > 0),
  check (ClosedDate is null or ClosedDate >= CreatedDate)
);

create table OrderServices (
  Id int identity primary key,
  OrderId int not null foreign key references Orders (Id) on delete cascade,
  ServiceId int not null foreign key references Services (Id)
);